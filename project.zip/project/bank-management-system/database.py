import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import random
from datetime import datetime

class Database:
    def __init__(self, db_path='bank.db'):
        self.db_path = db_path
    
    def get_connection(self):
        """Create database connection"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        """Initialize database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin', 'staff', 'customer')),
                status TEXT DEFAULT 'active' CHECK(status IN ('active', 'blocked')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Accounts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS accounts (
                account_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                account_number TEXT UNIQUE NOT NULL,
                account_type TEXT NOT NULL CHECK(account_type IN ('savings', 'current')),
                balance DECIMAL(15, 2) DEFAULT 0.00,
                status TEXT DEFAULT 'active' CHECK(status IN ('active', 'suspended', 'closed')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('deposit', 'withdrawal', 'transfer', 'account_creation')),
                amount DECIMAL(15, 2) NOT NULL,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                description TEXT,
                related_account TEXT,
                FOREIGN KEY (account_id) REFERENCES accounts (account_id)
            )
        ''')
        
        # Login log table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS login_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT NOT NULL CHECK(status IN ('success', 'failed')),
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Create default admin and staff users
        default_users = [
            ('admin', 'admin123', 'System Administrator', 'admin@bank.com', 'admin'),
            ('staff', 'staff123', 'Bank Staff', 'staff@bank.com', 'staff'),
        ]
        
        for username, password, full_name, email, role in default_users:
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
            if cursor.fetchone()[0] == 0:
                password_hash = generate_password_hash(password)
                cursor.execute('''
                    INSERT INTO users (username, password, full_name, email, role)
                    VALUES (?, ?, ?, ?, ?)
                ''', (username, password_hash, full_name, email, role))
        
        conn.commit()
        conn.close()
        print("✅ Database initialized successfully!")
    
    def generate_account_number(self):
        """Generate 10-digit account number"""
        return f"{random.randint(1000000000, 9999999999)}"
    
    def authenticate_user(self, username, password):
        """Authenticate user login"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        
        if user and check_password_hash(user['password'], password):
            if user['status'] == 'blocked':
                cursor.execute('INSERT INTO login_log (user_id, status) VALUES (?, ?)', 
                             (user['user_id'], 'failed'))
                conn.commit()
                conn.close()
                return None, "Account is blocked"
            
            cursor.execute('INSERT INTO login_log (user_id, status) VALUES (?, ?)', 
                         (user['user_id'], 'success'))
            conn.commit()
            
            user_data = {
                'user_id': user['user_id'],
                'username': user['username'],
                'full_name': user['full_name'],
                'role': user['role'],
                'email': user['email']
            }
            conn.close()
            return user_data, "Login successful"
        else:
            if user:
                cursor.execute('INSERT INTO login_log (user_id, status) VALUES (?, ?)', 
                             (user['user_id'], 'failed'))
                conn.commit()
            conn.close()
            return None, "Invalid credentials"
    
    def register_user(self, username, password, full_name, email, role='customer'):
        """Register new user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Check if user exists
            cursor.execute('SELECT * FROM users WHERE username = ? OR email = ?', (username, email))
            if cursor.fetchone():
                return False, "Username or email already exists"
            
            # Create user
            password_hash = generate_password_hash(password)
            cursor.execute('''
                INSERT INTO users (username, password, full_name, email, role)
                VALUES (?, ?, ?, ?, ?)
            ''', (username, password_hash, full_name, email, role))
            
            user_id = cursor.lastrowid
            
            # Create account for customer
            if role == 'customer':
                account_number = self.generate_account_number()
                cursor.execute('''
                    INSERT INTO accounts (user_id, account_number, account_type)
                    VALUES (?, ?, ?)
                ''', (user_id, account_number, 'savings'))
                
                account_id = cursor.lastrowid
                
                # Log account creation
                cursor.execute('''
                    INSERT INTO transactions (account_id, type, amount, description)
                    VALUES (?, ?, ?, ?)
                ''', (account_id, 'account_creation', 0.00, 'Account opened'))
            
            conn.commit()
            conn.close()
            return True, f"Registration successful! Account: {account_number if role == 'customer' else 'N/A'}"
        
        except Exception as e:
            conn.rollback()
            conn.close()
            return False, f"Error: {str(e)}"
    
    def get_user_accounts(self, user_id):
        """Get user's accounts"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM accounts WHERE user_id = ?', (user_id,))
        accounts = cursor.fetchall()
        conn.close()
        return accounts
    
    def get_all_users(self):
        """Get all users"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users ORDER BY created_at DESC')
        users = cursor.fetchall()
        conn.close()
        return users
    
    def get_all_accounts(self):
        """Get all accounts"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT a.*, u.username, u.full_name 
            FROM accounts a 
            JOIN users u ON a.user_id = u.user_id 
            ORDER BY a.created_at DESC
        ''')
        accounts = cursor.fetchall()
        conn.close()
        return accounts
    
    def get_all_transactions(self, limit=100):
        """Get all transactions"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.*, a.account_number, u.username 
            FROM transactions t 
            JOIN accounts a ON t.account_id = a.account_id 
            JOIN users u ON a.user_id = u.user_id 
            ORDER BY t.date DESC 
            LIMIT ?
        ''', (limit,))
        transactions = cursor.fetchall()
        conn.close()
        return transactions
    
    def update_user_status(self, user_id, status):
        """Update user status"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET status = ? WHERE user_id = ?', (status, user_id))
        conn.commit()
        conn.close()
        return True
    
    def create_customer_account(self, username, password, full_name, email, account_type='savings', initial_deposit=0):
        """Staff: Create customer account"""
        return self.register_user(username, password, full_name, email, 'customer')
    
    def deposit(self, account_number, amount, description=""):
        """Deposit money"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT * FROM accounts WHERE account_number = ?', (account_number,))
            account = cursor.fetchone()
            
            if not account:
                return False, "Account not found"
            
            new_balance = account['balance'] + amount
            cursor.execute('UPDATE accounts SET balance = ? WHERE account_number = ?', 
                         (new_balance, account_number))
            
            cursor.execute('''
                INSERT INTO transactions (account_id, type, amount, description)
                VALUES (?, ?, ?, ?)
            ''', (account['account_id'], 'deposit', amount, description))
            
            conn.commit()
            conn.close()
            return True, f"Deposited ${amount:.2f}. New balance: ${new_balance:.2f}"
        
        except Exception as e:
            conn.rollback()
            conn.close()
            return False, f"Error: {str(e)}"
    
    def withdraw(self, account_number, amount, description=""):
        """Withdraw money"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT * FROM accounts WHERE account_number = ?', (account_number,))
            account = cursor.fetchone()
            
            if not account:
                return False, "Account not found"
            
            if account['balance'] < amount:
                return False, "Insufficient balance"
            
            new_balance = account['balance'] - amount
            cursor.execute('UPDATE accounts SET balance = ? WHERE account_number = ?', 
                         (new_balance, account_number))
            
            cursor.execute('''
                INSERT INTO transactions (account_id, type, amount, description)
                VALUES (?, ?, ?, ?)
            ''', (account['account_id'], 'withdrawal', amount, description))
            
            conn.commit()
            conn.close()
            return True, f"Withdrew ${amount:.2f}. New balance: ${new_balance:.2f}"
        
        except Exception as e:
            conn.rollback()
            conn.close()
            return False, f"Error: {str(e)}"
    
    def transfer(self, from_account, to_account, amount, user_id, description=""):
        """Transfer money"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Verify from account belongs to user
            cursor.execute('SELECT * FROM accounts WHERE account_number = ? AND user_id = ?', 
                         (from_account, user_id))
            from_acc = cursor.fetchone()
            
            if not from_acc:
                return False, "Invalid source account"
            
            # Check to account exists
            cursor.execute('SELECT * FROM accounts WHERE account_number = ?', (to_account,))
            to_acc = cursor.fetchone()
            
            if not to_acc:
                return False, "Destination account not found"
            
            if from_acc['balance'] < amount:
                return False, "Insufficient balance"
            
            # Update balances
            cursor.execute('UPDATE accounts SET balance = balance - ? WHERE account_number = ?', 
                         (amount, from_account))
            cursor.execute('UPDATE accounts SET balance = balance + ? WHERE account_number = ?', 
                         (amount, to_account))
            
            # Log transactions
            cursor.execute('''
                INSERT INTO transactions (account_id, type, amount, description, related_account)
                VALUES (?, ?, ?, ?, ?)
            ''', (from_acc['account_id'], 'transfer', -amount, description, to_account))
            
            cursor.execute('''
                INSERT INTO transactions (account_id, type, amount, description, related_account)
                VALUES (?, ?, ?, ?, ?)
            ''', (to_acc['account_id'], 'transfer', amount, description, from_account))
            
            conn.commit()
            conn.close()
            return True, f"Transferred ${amount:.2f} to account {to_account}"
        
        except Exception as e:
            conn.rollback()
            conn.close()
            return False, f"Error: {str(e)}"
    
    def get_customer_transactions(self, user_id, limit=50):
        """Get customer transactions"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT account_id FROM accounts WHERE user_id = ?', (user_id,))
        account_ids = [row['account_id'] for row in cursor.fetchall()]
        
        if account_ids:
            placeholders = ','.join('?' for _ in account_ids)
            cursor.execute(f'''
                SELECT t.*, a.account_number 
                FROM transactions t 
                JOIN accounts a ON t.account_id = a.account_id 
                WHERE t.account_id IN ({placeholders}) 
                ORDER BY t.date DESC 
                LIMIT ?
            ''', account_ids + [limit])
            transactions = cursor.fetchall()
        else:
            transactions = []
        
        conn.close()
        return transactions
    
    def get_customers(self):
        """Get all customers"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT u.*, a.account_number, a.balance 
            FROM users u 
            LEFT JOIN accounts a ON u.user_id = a.user_id 
            WHERE u.role = 'customer'
        ''')
        customers = cursor.fetchall()
        conn.close()
        return customers
    
    def chatbot_response(self, message):
        """Simple rule-based chatbot"""
        message = message.lower().strip()
        
        responses = {
            'hello': 'Hello! How can I help you with your banking needs?',
            'hi': 'Hi there! Welcome to our banking assistance.',
            'balance': 'You can check your balance in the "View Balance" section.',
            'account': 'To open an account, visit our branch or contact staff.',
            'deposit': 'You can deposit money at any branch with your account details.',
            'withdraw': 'You can withdraw money from your account at any branch or ATM.',
            'transfer': 'Transfer money using the "Transfer Money" option.',
            'help': 'I can help with: balance, account, deposit, withdrawal, transfer.',
            'thank': 'You\'re welcome!',
            'bye': 'Goodbye! Thank you for banking with us.'
        }
        
        for keyword, response in responses.items():
            if keyword in message:
                return response
        
        return "I can help with banking queries. Ask about: balance, account, deposit, withdrawal, or transfer."