from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from functools import wraps
from database import Database

app = Flask(__name__)
app.config.from_object('config.Config')

db = Database()

# Initialize database
with app.app_context():
    db.init_db()

# Decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] not in roles:
                flash('Access denied', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Routes
@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        user, message = db.authenticate_user(username, password)
        
        if user:
            session['user_id'] = user['user_id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['full_name'] = user['full_name']
            flash('Login successful', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash(message, 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        
        # Validation
        if not all([username, password, confirm_password, full_name, email]):
            flash('All fields are required', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters', 'danger')
            return render_template('register.html')
        
        success, message = db.register_user(username, password, full_name, email)
        
        if success:
            flash(message, 'success')
            return redirect(url_for('login'))
        else:
            flash(message, 'danger')
    
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    role = session['role']
    
    if role == 'admin':
        # Get statistics
        users = db.get_all_users()
        accounts = db.get_all_accounts()
        transactions = db.get_all_transactions(10)
        
        return render_template('admin/dashboard.html',
                             users_count=len(users),
                             accounts_count=len(accounts),
                             recent_transactions=transactions)
    
    elif role == 'staff':
        customers = db.get_customers()
        accounts = db.get_all_accounts()
        
        return render_template('staff/dashboard.html',
                             customers_count=len(customers),
                             accounts_count=len(accounts))
    
    else:  # customer
        accounts = db.get_user_accounts(session['user_id'])
        transactions = db.get_customer_transactions(session['user_id'], 5)
        
        return render_template('customer/dashboard.html',
                             accounts=accounts,
                             transactions=transactions)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))

# Admin routes
@app.route('/admin/users')
@login_required
@role_required(['admin'])
def admin_users():
    users = db.get_all_users()
    return render_template('admin/users.html', users=users)

@app.route('/admin/accounts')
@login_required
@role_required(['admin'])
def admin_accounts():
    accounts = db.get_all_accounts()
    return render_template('admin/accounts.html', accounts=accounts)

@app.route('/admin/transactions')
@login_required
@role_required(['admin'])
def admin_transactions():
    transactions = db.get_all_transactions()
    return render_template('admin/transactions.html', transactions=transactions)

@app.route('/admin/toggle_user/<int:user_id>')
@login_required
@role_required(['admin'])
def toggle_user(user_id):
    users = db.get_all_users()
    user = next((u for u in users if u['user_id'] == user_id), None)
    
    if user:
        new_status = 'blocked' if user['status'] == 'active' else 'active'
        db.update_user_status(user_id, new_status)
        action = 'blocked' if new_status == 'blocked' else 'unblocked'
        flash(f'User {user["username"]} {action}', 'success')
    
    return redirect(url_for('admin_users'))

# Staff routes
@app.route('/staff/create_account', methods=['GET', 'POST'])
@login_required
@role_required(['staff'])
def create_account():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        account_type = request.form.get('account_type', 'savings')
        
        success, message = db.create_customer_account(username, password, full_name, email, account_type)
        
        if success:
            flash(message, 'success')
            return redirect(url_for('create_account'))
        else:
            flash(message, 'danger')
    
    return render_template('staff/create_account.html')

@app.route('/staff/deposit', methods=['GET', 'POST'])
@login_required
@role_required(['staff'])
def deposit():
    if request.method == 'POST':
        account_number = request.form.get('account_number', '').strip()
        amount = request.form.get('amount', '').strip()
        description = request.form.get('description', '').strip()
        
        try:
            amount = float(amount)
            if amount <= 0:
                flash('Amount must be positive', 'danger')
                return render_template('staff/deposit.html')
        except:
            flash('Invalid amount', 'danger')
            return render_template('staff/deposit.html')
        
        success, message = db.deposit(account_number, amount, description)
        
        if success:
            flash(message, 'success')
            return redirect(url_for('deposit'))
        else:
            flash(message, 'danger')
    
    return render_template('staff/deposit.html')

@app.route('/staff/withdraw', methods=['GET', 'POST'])
@login_required
@role_required(['staff'])
def withdraw():
    if request.method == 'POST':
        account_number = request.form.get('account_number', '').strip()
        amount = request.form.get('amount', '').strip()
        description = request.form.get('description', '').strip()
        
        try:
            amount = float(amount)
            if amount <= 0:
                flash('Amount must be positive', 'danger')
                return render_template('staff/withdraw.html')
        except:
            flash('Invalid amount', 'danger')
            return render_template('staff/withdraw.html')
        
        success, message = db.withdraw(account_number, amount, description)
        
        if success:
            flash(message, 'success')
            return redirect(url_for('withdraw'))
        else:
            flash(message, 'danger')
    
    return render_template('staff/withdraw.html')

@app.route('/staff/customers')
@login_required
@role_required(['staff'])
def customers():
    customers = db.get_customers()
    return render_template('staff/customers.html', customers=customers)

# Customer routes
@app.route('/customer/balance')
@login_required
@role_required(['customer'])
def balance():
    accounts = db.get_user_accounts(session['user_id'])
    return render_template('customer/balance.html', accounts=accounts)

@app.route('/customer/transactions')
@login_required
@role_required(['customer'])
def transactions():
    transactions = db.get_customer_transactions(session['user_id'])
    return render_template('customer/transactions.html', transactions=transactions)

@app.route('/customer/transfer', methods=['GET', 'POST'])
@login_required
@role_required(['customer'])
def transfer():
    accounts = db.get_user_accounts(session['user_id'])
    
    if request.method == 'POST':
        from_account = request.form.get('from_account', '').strip()
        to_account = request.form.get('to_account', '').strip()
        amount = request.form.get('amount', '').strip()
        description = request.form.get('description', '').strip()
        
        try:
            amount = float(amount)
            if amount <= 0:
                flash('Amount must be positive', 'danger')
                return render_template('customer/transfer.html', accounts=accounts)
        except:
            flash('Invalid amount', 'danger')
            return render_template('customer/transfer.html', accounts=accounts)
        
        success, message = db.transfer(from_account, to_account, amount, session['user_id'], description)
        
        if success:
            flash(message, 'success')
            return redirect(url_for('transfer'))
        else:
            flash(message, 'danger')
    
    return render_template('customer/transfer.html', accounts=accounts)

@app.route('/customer/chatbot', methods=['GET', 'POST'])
@login_required
@role_required(['customer'])
def chatbot():
    if request.method == 'POST':
        data = request.get_json()
        message = data.get('message', '')
        
        response = db.chatbot_response(message)
        return jsonify({'response': response})
    
    return render_template('customer/chatbot.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)