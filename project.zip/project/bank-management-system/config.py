import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'bank-management-secret-key-2024'
    DATABASE = 'bank.db'
    SESSION_TYPE = 'filesystem'